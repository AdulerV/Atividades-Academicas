public class Professor extends Pessoa {

}
