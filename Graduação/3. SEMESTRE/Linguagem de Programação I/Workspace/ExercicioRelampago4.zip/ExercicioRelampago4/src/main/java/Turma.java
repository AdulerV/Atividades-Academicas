import java.util.ArrayList;

public class Turma {
    private Professor professor;
    private ArrayList<Aluno> alunos;

    public Turma() {
        this.alunos = new ArrayList<Aluno>();
    }

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public String getNomeProfessor() {
        return professor.getNome();
    }

    public ArrayList<Aluno> getAlunos() {
        return alunos;
    }

    public void setAlunos(ArrayList<Aluno> alunos) {
        this.alunos = alunos;
    }

    public void adicionarAluno(Aluno aluno) {
        if(aluno == null || verificarAluno(aluno)) {
            throw new IllegalArgumentException("Aluno inválido!");
        }
        this.alunos.add(aluno);
    }

    public boolean verificarAluno(Aluno aluno) {
        return this.alunos.contains(aluno);
    }

    public ArrayList<String> listarNomesAlunos() {
        ArrayList<String> nomes = new ArrayList<String>();

        for (Aluno aluno : this.alunos) {
            nomes.add(aluno.getNome());
        }
        return nomes;
    }
}
