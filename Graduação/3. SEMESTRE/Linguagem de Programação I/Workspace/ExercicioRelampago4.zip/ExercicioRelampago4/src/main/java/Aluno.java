public class Aluno extends Pessoa {

}
