import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.Assertions.*;
import static org.junit.Assert.assertEquals;

class TurmaTest {
    @Test
    public void deveInserirNomeProfessorTurma() {
        Professor professor = new Professor();
        professor.setNome("Marco Antônio");
        Turma turma = new Turma();
        turma.setProfessor(professor);
        assertEquals("Marco Antônio", turma.getNomeProfessor());
    }

    @Test
    public void deveListarNomesAlunosTurma() {
        Turma turma = new Turma();

        Aluno aluno1 = new Aluno();
        aluno1.setNome("João Pedro");
        turma.adicionarAluno(aluno1);

        Aluno aluno2 = new Aluno();
        aluno2.setNome("Arthur de Oliveira");
        turma.adicionarAluno(aluno2);

        Aluno aluno3 = new Aluno();
        aluno3.setNome("Lucas Souza");
        turma.adicionarAluno(aluno3);

        assertEquals("[João Pedro, Arthur de Oliveira, Lucas Souza]", turma.listarNomesAlunos().toString());
    }



}