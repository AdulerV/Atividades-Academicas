import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CursoTest {
    @Test
    public void deveListarNomesProfessoresTurmas() {
        Professor professor1 = new Professor();
        professor1.setNome("Marco Antônio");

        Professor professor2 = new Professor();
        professor2.setNome("Hilton Martins");

        Professor professor3 = new Professor();
        professor3.setNome("Sandro Fernandes");

        Turma turma1 = new Turma();
        turma1.setProfessor(professor1);

        Turma turma2 = new Turma();
        turma2.setProfessor(professor2);

        Turma turma3 = new Turma();
        turma3.setProfessor(professor3);

        Curso curso = new Curso();
        curso.adicionarTurma(turma1);
        curso.adicionarTurma(turma2);
        curso.adicionarTurma(turma3);

        assertEquals("[Marco Antônio, Hilton Martins, Sandro Fernandes]", curso.listarNomesProfessoresTurmas().toString());
    }

    @Test
    public void deveListarNomesAlunosTurmas() {
        Turma turma1 = new Turma();

        Aluno aluno1 = new Aluno();
        aluno1.setNome("João Pedro");
        turma1.adicionarAluno(aluno1);

        Aluno aluno2 = new Aluno();
        aluno2.setNome("Arthur de Oliveira");
        turma1.adicionarAluno(aluno2);

        Aluno aluno3 = new Aluno();
        aluno3.setNome("Lucas Souza");
        turma1.adicionarAluno(aluno3);

        Turma turma2 = new Turma();

        Aluno aluno4 = new Aluno();
        aluno4.setNome("Luan Pereira");
        turma2.adicionarAluno(aluno4);

        Aluno aluno5 = new Aluno();
        aluno5.setNome("Nadine de Carvalho");
        turma2.adicionarAluno(aluno5);

        Aluno aluno6 = new Aluno();
        aluno6.setNome("Pedro Faria");
        turma2.adicionarAluno(aluno6);

        Curso curso = new Curso();
        curso.adicionarTurma(turma1);
        curso.adicionarTurma(turma2);

        assertEquals("[[João Pedro, Arthur de Oliveira, Lucas Souza], [Luan Pereira, Nadine de Carvalho, Pedro Faria]]", curso.listarNomesAlunosTurmas().toString());
    }

    @Test
    public void deveListarNomesAlunos() {
        Curso curso = new Curso();

        Aluno aluno1 = new Aluno();
        aluno1.setNome("João Pedro");
        curso.adicionarAluno(aluno1);

        Aluno aluno2 = new Aluno();
        aluno2.setNome("Arthur de Oliveira");
        curso.adicionarAluno(aluno2);

        Aluno aluno3 = new Aluno();
        aluno3.setNome("Lucas Souza");
        curso.adicionarAluno(aluno3);

        
    }
}